sudo apt-get update
sudo apt-get install default-jdk

